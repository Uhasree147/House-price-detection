import pandas as pd
import zipfile
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np

# Step 1: Extract the ZIP File
zip_file_path = "archive.zip"  # Ensure this file is in the same directory
extract_folder = "dataset_folder"

# Extract if not already extracted
if not os.path.exists(extract_folder):
    with zipfile.ZipFile(zip_file_path, "r") as zip_ref:
        zip_ref.extractall(extract_folder)

# Step 2: Load the dataset
csv_file_path = os.path.join(extract_folder, "Housing.csv")  # Ensure correct filename
df = pd.read_csv(csv_file_path)

# Step 3: Encode categorical variables
categorical_columns = ["mainroad", "guestroom", "basement", "hotwaterheating",
                        "airconditioning", "prefarea", "furnishingstatus"]

label_encoders = {}
for col in categorical_columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])

# Step 4: Scale numerical features
numerical_columns = ["area", "bedrooms", "bathrooms", "stories", "parking"]
scaler = StandardScaler()
df[numerical_columns] = scaler.fit_transform(df[numerical_columns])

# Step 5: Define X (features) and y (target)
X = df.drop(columns=["price"])
y = df["price"]

# Step 6: Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 7: Train Regression Models

# Linear Regression
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

# Decision Tree Regressor
dt_model = DecisionTreeRegressor(random_state=42)
dt_model.fit(X_train, y_train)

# XGBoost Regressor
xgb_model = XGBRegressor(objective="reg:squarederror", random_state=42)
xgb_model.fit(X_train, y_train)

print("Models trained successfully!")

# Step 8: Model Evaluation Function
def evaluate_model(model, X_test, y_test, name):
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"{name} Performance:")
    print(f"  RMSE: {rmse:.2f}")
    print(f"  MAE: {mae:.2f}")
    print(f"  R² Score: {r2:.2f}\n")

# Step 9: Evaluate all models
evaluate_model(lr_model, X_test, y_test, "Linear Regression")
evaluate_model(dt_model, X_test, y_test, "Decision Tree Regressor")
evaluate_model(xgb_model, X_test, y_test, "XGBoost Regressor")

